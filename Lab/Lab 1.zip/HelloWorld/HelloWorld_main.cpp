/* 
 * File:   main.cpp  HelloWorld, second attempt
 * Author: Elizabeth Pardo
 * Purpose: To write something interesting and make it work in NetBeans.
 * Created on June 24, 2015, 6:25 PM
 */

//System Libraries
#include <iostream> //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global constants

//Function Prototypes

//Execution Begins
int main(int argc, char** argv) {
    //Declare Variables Here
    
    //Input Values Here
    
    //Process Input Here
    
    //Output Unknowns Here
    cout<<"Hey Y'all"<<endl;
    //Exit pursued by a bear
    return 0;
}

